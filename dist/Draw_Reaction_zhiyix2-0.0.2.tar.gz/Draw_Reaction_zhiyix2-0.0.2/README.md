# Draw_Reaction

To setup the environment for executing "python Draw_Reaction.py" you need to install the Tkinter
You can execute "pip install tk" in the terminal
Run the program by executing "python Draw_Reaction.py"

You can also modify the input file in the "Draw_Reaction.py" by changing the input file on the line 87
    reaction_list = Read_Compound_Reaction.get_reaction_list(Read_Reactions.readFile("<Input File>"))
